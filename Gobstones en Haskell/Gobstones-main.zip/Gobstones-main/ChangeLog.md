# Changelog for proyecto-base

## Unreleased changes
